import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail } from "lucide-react";
import { z } from "zod";

const emailSchema = z.object({
  email: z.string().email("Bitte geben Sie eine gültige E-Mail-Adresse ein"),
});

export default function Newsletter() {
  const [email, setEmail] = useState("");
  const { toast } = useToast();

  const subscriptionMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await fetch('/api/newsletter/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Erfolgreich angemeldet!",
        description: "Sie erhalten eine Bestätigungs-E-Mail in Kürze.",
      });
      setEmail("");
    },
    onError: (error) => {
      toast({
        title: "Anmeldung fehlgeschlagen",
        description: error instanceof Error ? error.message : "Ein Fehler ist aufgetreten",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      emailSchema.parse({ email });
      subscriptionMutation.mutate(email);
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Ungültige E-Mail",
          description: error.errors[0].message,
          variant: "destructive",
        });
      }
    }
  };

  return (
    <section className="py-16 bg-gradient-to-r from-[var(--genius-primary)] to-[var(--genius-secondary)] text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl font-bold mb-4">Bleiben Sie informiert</h2>
        <p className="text-xl text-blue-100 mb-8">
          Erhalten Sie wöchentliche Updates zu neuen Tarifen und Optimierungsmöglichkeiten
        </p>
        
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
          <Input
            type="email"
            placeholder="Ihre E-Mail-Adresse"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="flex-1 px-6 py-3 text-gray-900 bg-white border-0 focus:ring-4 focus:ring-white/30"
            disabled={subscriptionMutation.isPending}
          />
          <Button
            type="submit"
            disabled={subscriptionMutation.isPending}
            className="bg-white text-[var(--genius-primary)] hover:bg-gray-100 px-8 py-3 font-semibold transition-colors"
          >
            <Mail className="mr-2 h-4 w-4" />
            {subscriptionMutation.isPending ? 'Wird angemeldet...' : 'Abonnieren'}
          </Button>
        </form>
        
        <p className="text-sm text-blue-100 mt-4">
          Kostenlos und jederzeit kündbar. Datenschutz garantiert.
        </p>
      </div>
    </section>
  );
}
