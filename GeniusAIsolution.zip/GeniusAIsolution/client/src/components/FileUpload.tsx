import { useState, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useDropzone } from "react-dropzone";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CloudUpload, FileUp, CheckCircle, AlertCircle } from "lucide-react";

interface FileUploadProps {
  onSuccess?: () => void;
}

export default function FileUpload({ onSuccess }: FileUploadProps) {
  const [uploadProgress, setUploadProgress] = useState(0);
  const [currentFile, setCurrentFile] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('file', file);

      setCurrentFile(file.name);
      setUploadProgress(0);
      setIsProcessing(true);

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      const response = await fetch('/api/contracts/upload', {
        method: 'POST',
        body: formData,
        credentials: 'include',
      });

      clearInterval(progressInterval);
      setUploadProgress(100);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }

      return response.json();
    },
    onSuccess: (data) => {
      setIsProcessing(false);
      toast({
        title: "Upload erfolgreich",
        description: "Ihr Vertrag wurde erfolgreich analysiert!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      onSuccess?.();
      
      // Reset states
      setTimeout(() => {
        setUploadProgress(0);
        setCurrentFile("");
      }, 2000);
    },
    onError: (error) => {
      setIsProcessing(false);
      setUploadProgress(0);
      setCurrentFile("");
      
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      toast({
        title: "Upload fehlgeschlagen",
        description: error instanceof Error ? error.message : "Ein Fehler ist aufgetreten",
        variant: "destructive",
      });
    },
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      
      // Validate file size (10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "Datei zu groß",
          description: "Die Datei darf maximal 10MB groß sein.",
          variant: "destructive",
        });
        return;
      }
      
      uploadMutation.mutate(file);
    }
  }, [uploadMutation, toast]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png'],
      'image/gif': ['.gif'],
    },
    multiple: false,
    disabled: uploadMutation.isPending,
  });

  return (
    <section className="py-16 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Vertrag hochladen und analysieren</h2>
          <p className="text-xl text-gray-600">Laden Sie Ihre Verträge hoch - unsere KI analysiert sie automatisch</p>
        </div>
        
        {/* Upload Area */}
        <Card className="border-2 border-dashed border-gray-300 hover:border-[var(--genius-primary)] transition-colors duration-200">
          <CardContent className="p-12">
            <div
              {...getRootProps()}
              className={`text-center cursor-pointer ${isDragActive ? 'scale-105' : ''} transition-transform duration-200`}
            >
              <input {...getInputProps()} />
              <div className="space-y-6">
                <div className="mx-auto w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center">
                  <CloudUpload className="h-8 w-8 text-[var(--genius-primary)]" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {isDragActive 
                      ? "Datei hier ablegen..." 
                      : "Verträge hierher ziehen oder klicken zum Auswählen"
                    }
                  </h3>
                  <p className="text-gray-600">PDF, PNG, JPG bis zu 10MB</p>
                </div>
                {!uploadMutation.isPending && (
                  <Button className="btn-genius-primary">
                    <FileUp className="mr-2 h-4 w-4" />
                    Dateien auswählen
                  </Button>
                )}
              </div>
            </div>

            {/* Upload Progress */}
            {(uploadMutation.isPending || uploadProgress > 0) && (
              <div className="mt-8 space-y-4">
                <Card className="bg-gray-50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">{currentFile}</span>
                      <span className="text-sm text-gray-500">{uploadProgress}%</span>
                    </div>
                    <Progress value={uploadProgress} className="h-2" />
                  </CardContent>
                </Card>
                
                {/* Processing Status */}
                {isProcessing && uploadProgress < 100 && (
                  <Card className="bg-blue-50 border-blue-200">
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[var(--genius-primary)] mr-3"></div>
                        <span className="text-sm text-blue-700">
                          {uploadProgress < 50 ? "Datei wird hochgeladen..." : 
                           uploadProgress < 90 ? "OCR-Texterkennung läuft..." : 
                           "KI-Analyse wird durchgeführt..."}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                )}

                {/* Success Status */}
                {uploadProgress === 100 && !isProcessing && (
                  <Card className="bg-green-50 border-green-200">
                    <CardContent className="p-4">
                      <div className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-600 mr-3" />
                        <span className="text-sm text-green-700">Vertrag erfolgreich analysiert!</span>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
