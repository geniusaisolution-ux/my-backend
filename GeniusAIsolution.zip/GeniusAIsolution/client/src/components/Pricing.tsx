import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check } from "lucide-react";

export default function Pricing() {
  const plans = [
    {
      name: "Starter",
      price: "9,99",
      period: "pro Monat",
      features: [
        "Bis zu 5 Verträge",
        "Grundlegende KI-Analyse", 
        "E-Mail-Erinnerungen",
        "Dashboard-Zugang"
      ],
      buttonText: "Plan wählen",
      buttonStyle: "bg-gray-900 hover:bg-gray-800 text-white",
      popular: false
    },
    {
      name: "Professional", 
      price: "29,99",
      period: "pro Monat",
      features: [
        "Unbegrenzte Verträge",
        "Erweiterte KI-Analyse",
        "Automatische Optimierung",
        "Priority Support",
        "API-Zugang"
      ],
      buttonText: "Plan wählen",
      buttonStyle: "btn-genius-primary",
      popular: true
    },
    {
      name: "Enterprise",
      price: "99,99", 
      period: "pro Monat",
      features: [
        "White-Label-Lösung",
        "Dedizierter Account Manager",
        "Custom Integrationen",
        "24/7 Premium Support",
        "SLA-Garantie"
      ],
      buttonText: "Kontakt aufnehmen",
      buttonStyle: "bg-gray-900 hover:bg-gray-800 text-white",
      popular: false
    }
  ];

  const handlePlanSelect = (planName: string) => {
    window.location.href = "/api/login";
  };

  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Transparente Preise</h2>
          <p className="text-xl text-gray-600">Wählen Sie den Plan, der zu Ihnen passt</p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card 
              key={index}
              className={`shadow-lg hover:shadow-xl transition-all duration-300 ${
                plan.popular 
                  ? 'border-2 border-[var(--genius-primary)] scale-105 relative' 
                  : 'border border-gray-200'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <span className="bg-[var(--genius-primary)] text-white px-6 py-2 rounded-full text-sm font-semibold">
                    BELIEBT
                  </span>
                </div>
              )}
              
              <CardContent className="p-8 text-center">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <div className={`text-4xl font-bold mb-1 ${plan.popular ? 'text-[var(--genius-primary)]' : 'text-gray-900'}`}>
                  €{plan.price}
                </div>
                <div className="text-gray-600 mb-8">{plan.period}</div>
                
                <ul className="space-y-4 mb-8 text-left">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center">
                      <Check className="h-4 w-4 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <Button
                  onClick={() => handlePlanSelect(plan.name)}
                  className={`w-full ${plan.buttonStyle} transition-colors`}
                >
                  {plan.buttonText}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
