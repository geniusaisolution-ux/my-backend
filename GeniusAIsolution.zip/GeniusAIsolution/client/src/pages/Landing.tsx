import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import FileUpload from "@/components/FileUpload";
import Services from "@/components/Services";
import AIAnalysisDemo from "@/components/AIAnalysisDemo";
import Pricing from "@/components/Pricing";
import Stats from "@/components/Stats";
import Newsletter from "@/components/Newsletter";
import Footer from "@/components/Footer";
import Chatbot from "@/components/Chatbot";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <Hero />
      <Stats />
      <FileUpload />
      <Services />
      <AIAnalysisDemo />
      <Pricing />
      <Newsletter />
      <Footer />
      <Chatbot />
    </div>
  );
}
