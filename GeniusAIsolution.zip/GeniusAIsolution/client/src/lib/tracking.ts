// Client-side tracking utilities for Check24 affiliate program
import { apiRequest } from './queryClient';

export interface TrackingConfig {
  category: string;
  subcategory: string;
  provider?: string;
  postcode?: string;
}

// Generate Check24 tracking URL via API
export async function generateTrackingUrl(config: TrackingConfig): Promise<string> {
  try {
    const params = new URLSearchParams({
      category: config.category,
      subcategory: config.subcategory,
      ...(config.provider && { provider: config.provider }),
      ...(config.postcode && { postcode: config.postcode }),
    });

    const response = await fetch(`/api/tracking/comparison-url?${params.toString()}`);
    
    if (!response.ok) {
      throw new Error('Failed to generate tracking URL');
    }

    const data = await response.json();
    return data.url;
  } catch (error) {
    console.error('Error generating tracking URL:', error);
    // Fallback to Check24 main page if tracking URL generation fails
    return 'https://www.check24.de';
  }
}

// Track click event for analytics
export async function trackClick(url: string, category: string, subcategory: string): Promise<void> {
  try {
    await apiRequest('/api/tracking/click', 'POST', {
      url,
      category,
      subcategory
    });
  } catch (error) {
    console.error('Failed to track click:', error);
    // Don't throw - tracking failures shouldn't break user experience
  }
}

// Open tracking URL in new tab and track the click
export async function openTrackingUrl(config: TrackingConfig): Promise<void> {
  try {
    const url = await generateTrackingUrl(config);
    
    // Track the click event
    await trackClick(url, config.category, config.subcategory);
    
    // Open in new tab
    window.open(url, '_blank', 'noopener,noreferrer');
  } catch (error) {
    console.error('Error opening tracking URL:', error);
    // Fallback - open Check24 main page
    window.open('https://www.check24.de', '_blank', 'noopener,noreferrer');
  }
}

// Helper functions for common contract categories
export const trackingHelpers = {
  openEnergyComparison: (subcategory: 'strom' | 'gas' | 'oekostrom', postcode?: string) => 
    openTrackingUrl({ category: 'energy', subcategory, postcode }),
    
  openTelecomComparison: (subcategory: 'internet' | 'mobile' | 'dsl', postcode?: string) => 
    openTrackingUrl({ category: 'telecom', subcategory, postcode }),
    
  openInsuranceComparison: (subcategory: 'kfz' | 'haftpflicht' | 'hausrat', postcode?: string) => 
    openTrackingUrl({ category: 'insurance', subcategory, postcode }),
};