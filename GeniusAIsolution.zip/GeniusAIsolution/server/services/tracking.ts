// Check24 Partner Program Tracking Service
export class TrackingService {
  private readonly check24PartnerId = process.env.CHECK24_PARTNER_ID || 'YOUR_CHECK24_PARTNER_ID';
  
  // Generate Check24 affiliate tracking URL for energy contracts
  generateCheck24EnergyUrl(category: 'strom' | 'gas' | 'oekostrom', postcode?: string): string {
    const baseUrl = 'https://www.check24.de';
    let path = '';
    
    switch (category) {
      case 'strom':
        path = '/strom/';
        break;
      case 'gas':
        path = '/gas/';
        break;
      case 'oekostrom':
        path = '/strom/?oekostrom=1';
        break;
    }
    
    const params = new URLSearchParams({
      pid: this.check24PartnerId,
      ...(postcode && { plz: postcode })
    });
    
    return `${baseUrl}${path}?${params.toString()}`;
  }
  
  // Generate Check24 affiliate tracking URL for telecom contracts
  generateCheck24TelecomUrl(category: 'dsl' | 'mobilfunk' | 'internet', postcode?: string): string {
    const baseUrl = 'https://www.check24.de';
    let path = '';
    
    switch (category) {
      case 'dsl':
      case 'internet':
        path = '/dsl/';
        break;
      case 'mobilfunk':
        path = '/handytarife/';
        break;
    }
    
    const params = new URLSearchParams({
      pid: this.check24PartnerId,
      ...(postcode && { plz: postcode })
    });
    
    return `${baseUrl}${path}?${params.toString()}`;
  }
  
  // Generate Check24 affiliate tracking URL for insurance
  generateCheck24InsuranceUrl(category: 'kfz' | 'haftpflicht' | 'hausrat', postcode?: string): string {
    const baseUrl = 'https://www.check24.de';
    let path = '';
    
    switch (category) {
      case 'kfz':
        path = '/kfz-versicherung/';
        break;
      case 'haftpflicht':
        path = '/privathaftpflicht/';
        break;
      case 'hausrat':
        path = '/hausratversicherung/';
        break;
    }
    
    const params = new URLSearchParams({
      pid: this.check24PartnerId,
      ...(postcode && { plz: postcode })
    });
    
    return `${baseUrl}${path}?${params.toString()}`;
  }
  
  // Generate tracking URL for optimization recommendations
  generateOptimizationTrackingUrl(
    category: string,
    subcategory: string,
    provider?: string,
    postcode?: string
  ): string {
    // Map categories to Check24 URLs
    if (category === 'energy') {
      if (subcategory === 'strom') return this.generateCheck24EnergyUrl('strom', postcode);
      if (subcategory === 'gas') return this.generateCheck24EnergyUrl('gas', postcode);
      if (subcategory === 'oekostrom') return this.generateCheck24EnergyUrl('oekostrom', postcode);
    }
    
    if (category === 'telecom') {
      if (subcategory === 'internet' || subcategory === 'dsl') {
        return this.generateCheck24TelecomUrl('dsl', postcode);
      }
      if (subcategory === 'mobile' || subcategory === 'mobilfunk') {
        return this.generateCheck24TelecomUrl('mobilfunk', postcode);
      }
    }
    
    if (category === 'insurance') {
      if (subcategory === 'kfz') return this.generateCheck24InsuranceUrl('kfz', postcode);
      if (subcategory === 'haftpflicht') return this.generateCheck24InsuranceUrl('haftpflicht', postcode);
      if (subcategory === 'hausrat') return this.generateCheck24InsuranceUrl('hausrat', postcode);
    }
    
    // Default fallback with partner ID
    const params = new URLSearchParams({
      pid: this.check24PartnerId,
      ...(postcode && { plz: postcode })
    });
    
    return `https://www.check24.de/?${params.toString()}`;
  }
  
  // Track user click events for analytics
  async trackClick(userId: string, url: string, category: string, subcategory: string): Promise<void> {
    try {
      // Log tracking event for analytics
      console.log(`[TRACKING] User ${userId} clicked ${category}/${subcategory} link: ${url}`);
      
      // Here you could also store tracking events in database if needed
      // await storage.createTrackingEvent({
      //   userId,
      //   url,
      //   category,
      //   subcategory,
      //   timestamp: new Date()
      // });
    } catch (error) {
      console.error('Failed to track click event:', error);
    }
  }
}

export const trackingService = new TrackingService();