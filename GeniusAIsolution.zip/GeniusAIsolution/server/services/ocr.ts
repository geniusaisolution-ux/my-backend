import { createWorker } from 'tesseract.js';
import fs from 'fs';
import path from 'path';

export class OCRService {
  private worker: any = null;

  async initialize() {
    if (!this.worker) {
      this.worker = await createWorker('deu'); // German language
      await this.worker.setParameters({
        tessedit_char_whitelist: 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzÄÖÜäöüß0123456789.,€€ -/:()[]',
      });
    }
  }

  async extractText(filePath: string): Promise<string> {
    await this.initialize();
    
    try {
      const { data: { text } } = await this.worker.recognize(filePath);
      return text.trim();
    } catch (error) {
      console.error('OCR extraction failed:', error);
      throw new Error('Failed to extract text from document');
    }
  }

  async extractTextFromBuffer(buffer: Buffer, filename: string): Promise<string> {
    await this.initialize();
    
    try {
      const { data: { text } } = await this.worker.recognize(buffer);
      return text.trim();
    } catch (error) {
      console.error('OCR extraction failed:', error);
      throw new Error('Failed to extract text from document');
    }
  }

  async terminate() {
    if (this.worker) {
      await this.worker.terminate();
      this.worker = null;
    }
  }
}

export const ocrService = new OCRService();
