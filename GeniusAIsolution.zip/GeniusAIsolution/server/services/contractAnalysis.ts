import { aiService } from './ai';
import { ocrService } from './ocr';
import { storage } from '../storage';
import type { InsertContract } from '@shared/schema';

export class ContractAnalysisService {
  async analyzeContractFile(
    buffer: Buffer,
    filename: string,
    userId: string
  ): Promise<string> {
    try {
      // Extract text using OCR
      const ocrText = await ocrService.extractTextFromBuffer(buffer, filename);
      
      if (!ocrText.trim()) {
        throw new Error('No text could be extracted from the document');
      }

      // Analyze with AI
      const analysis = await aiService.analyzeContract(ocrText);
      
      // Generate optimization suggestions
      const optimizations = await aiService.generateOptimizationSuggestions(
        analysis,
        analysis.category,
        undefined // postcode can be added later from user profile
      );

      // Create contract record
      const contractData: InsertContract = {
        userId,
        provider: analysis.provider || 'Unbekannt',
        category: analysis.category || 'other',
        subcategory: analysis.subcategory,
        contractNumber: analysis.contractNumber,
        monthlyCost: analysis.monthlyCost.toString(),
        startDate: analysis.startDate || null,
        endDate: analysis.endDate || null,
        cancellationDate: analysis.cancellationDate || null,
        status: analysis.optimizationPotential > 50 ? 'needs_review' : 'active',
        ocrText,
        aiAnalysis: analysis,
        optimizationSuggestions: optimizations,
        fileName: filename,
      };

      const contract = await storage.createContract(contractData);

      // Schedule cancellation reminder if applicable
      if (analysis.cancellationDate) {
        const reminderDate = new Date(analysis.cancellationDate);
        reminderDate.setDate(reminderDate.getDate() - 30); // 30 days before cancellation

        if (reminderDate > new Date()) {
          await storage.createEmailNotification({
            userId,
            contractId: contract.id,
            type: 'cancellation_reminder',
            scheduledFor: reminderDate,
          });
        }
      }

      return contract.id;
    } catch (error) {
      console.error('Contract analysis failed:', error);
      throw error;
    }
  }

  async reanalyzeContract(contractId: string, userId: string): Promise<boolean> {
    try {
      const contract = await storage.getContract(contractId, userId);
      if (!contract || !contract.ocrText) {
        throw new Error('Contract not found or no OCR text available');
      }

      // Re-analyze with AI
      const analysis = await aiService.analyzeContract(contract.ocrText);
      const optimizations = await aiService.generateOptimizationSuggestions(
        analysis,
        analysis.category,
        undefined // postcode can be added later from user profile
      );

      // Update contract
      await storage.updateContract(contractId, userId, {
        aiAnalysis: analysis,
        optimizationSuggestions: optimizations,
        status: analysis.optimizationPotential > 50 ? 'needs_review' : 'active',
      });

      return true;
    } catch (error) {
      console.error('Contract re-analysis failed:', error);
      return false;
    }
  }

  async getContractStats(userId: string) {
    try {
      const contracts = await storage.getContracts(userId);
      
      const stats = {
        totalContracts: contracts.length,
        activeContracts: contracts.filter(c => c.status === 'active').length,
        monthlyCosts: contracts.reduce((sum, c) => sum + parseFloat(c.monthlyCost), 0),
        potentialSavings: 0,
        upcomingCancellations: 0,
      };

      // Calculate potential savings and upcoming cancellations
      contracts.forEach(contract => {
        if (contract.optimizationSuggestions) {
          const opts = contract.optimizationSuggestions as any;
          if (opts.potentialSavings) {
            stats.potentialSavings += opts.potentialSavings / 12; // Monthly savings
          }
        }

        if (contract.cancellationDate) {
          const cancellationDate = new Date(contract.cancellationDate);
          const threeMonthsFromNow = new Date();
          threeMonthsFromNow.setMonth(threeMonthsFromNow.getMonth() + 3);
          
          if (cancellationDate <= threeMonthsFromNow) {
            stats.upcomingCancellations++;
          }
        }
      });

      return stats;
    } catch (error) {
      console.error('Failed to get contract stats:', error);
      throw error;
    }
  }
}

export const contractAnalysisService = new ContractAnalysisService();
